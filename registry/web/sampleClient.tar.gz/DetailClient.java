import electric.registry.Registry;

public class DetailClient {
   public static void main(String[] args) throws Exception {
      //IDetail detail = itemDetailHelper.bind();
      IDetail detail = itemDetailHelper.bind("http://wip.dublincore.org:8080/axis/services/itemDetail?wsdl");
      System.out.println("bind complete");
      String result = detail.getItemDetail(args[0], args[1]);
      System.out.println(result);
   }
}
