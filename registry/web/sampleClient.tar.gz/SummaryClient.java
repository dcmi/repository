import electric.registry.Registry;

public class SummaryClient {
   public static void main(String[] args) throws Exception {
      //IDetail detail = itemDetailHelper.bind();
      ISummary summary = itemSummaryHelper.bind("http://wip.dublincore.org:8080/axis/services/itemSummary?wsdl");
      System.out.println("bind complete");
      String result = summary.listItemSummary();
      System.out.println(result);
   }
}
